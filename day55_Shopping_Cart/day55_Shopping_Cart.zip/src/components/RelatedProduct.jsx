import React from 'react'

const RelatedProduct = () => {
  return (
    <div>RelatedProduct</div>
  )
}

export default RelatedProduct